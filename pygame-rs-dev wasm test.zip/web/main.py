# web 宿主自包含测试脚本（单文件；?script=main.py 缺省载荷）
import pygame


async def main():
    screen = pygame.display.set_mode((400, 300))
    font = pygame.font.Font(None, 48)
    f = 0
    while f < 600:
        with screen.render() as r:
            r.fill((255, 140, 0))
            r.blit(font.render("WEB RUN OK", True, (20, 20, 20)), (60, 120))
        pygame.display.flip()
        f += 1
        await pygame.next_frame()
