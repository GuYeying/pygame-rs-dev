/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_get_streamconfig_buffer_size: (a: number) => number;
export const __wbg_get_streamconfig_channels: (a: number) => number;
export const main: (a: number, b: number) => number;
export const __wbg_get_streamconfig_sample_rate: (a: number) => number;
export const __wbg_set_streamconfig_buffer_size: (a: number, b: number) => void;
export const __wbg_set_streamconfig_channels: (a: number, b: number) => void;
export const __wbg_set_streamconfig_sample_rate: (a: number, b: number) => void;
export const __wbg_streamconfig_free: (a: number, b: number) => void;
export const load_code: (a: number, b: number) => void;
export const web_start: () => void;
export const __wasm_bindgen_func_elem_13132: (a: number, b: number, c: number, d: number) => void;
export const __wasm_bindgen_func_elem_13132_14: (a: number, b: number, c: number, d: number) => void;
export const __wasm_bindgen_func_elem_13132_15: (a: number, b: number, c: number, d: number) => void;
export const __wasm_bindgen_func_elem_37466: (a: number, b: number, c: number, d: number) => void;
export const __wasm_bindgen_func_elem_40031: (a: number, b: number, c: number, d: number) => void;
export const __wasm_bindgen_func_elem_40033: (a: number, b: number, c: number, d: number) => void;
export const __wasm_bindgen_func_elem_13133: (a: number, b: number, c: number) => void;
export const __wasm_bindgen_func_elem_37465: (a: number, b: number, c: number) => void;
export const __wasm_bindgen_func_elem_37468: (a: number, b: number) => void;
export const __wbindgen_export: (a: number, b: number) => number;
export const __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export3: (a: number) => void;
export const __wbindgen_export4: (a: number, b: number) => void;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_start: () => void;
