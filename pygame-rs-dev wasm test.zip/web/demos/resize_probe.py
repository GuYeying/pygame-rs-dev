# 尺寸切换探针：400×300 橙色 30 帧 → 中途 set_mode 切 800×600 蓝色 30 帧
import pygame


async def main():
    screen = pygame.display.set_mode((400, 300))
    for _ in range(30):
        with screen.render() as r:
            r.fill((255, 140, 0))
        pygame.display.flip()
        await pygame.next_frame()
    screen = pygame.display.set_mode((800, 600))
    font = pygame.font.Font(None, 60)
    for _ in range(30):
        with screen.render() as r:
            r.fill((0, 120, 255))
            r.blit(font.render("RESIZE OK", True, (255, 255, 255)), (220, 260))
        pygame.display.flip()
        await pygame.next_frame()
